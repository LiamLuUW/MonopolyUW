#include "view.h"


using namespace std;


View::View ( ) { }

View::~View ( ) { }

void View::Notify (char piece, string cellname, int numofimp) { }

void View::notify (int oldpos, int newpos, char piece ) { };

void View::notify (int pos, int level ) { }

void View::draw ( ) { }
